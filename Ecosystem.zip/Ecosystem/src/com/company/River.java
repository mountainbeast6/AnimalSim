package com.company;

public class River {
    Animal river[][];
    public River(int num, int numx){
        river = new Animal[num][numx];
    }
    public River(){
        river = new Animal[10][10];
    }
    public boolean addAnimal(Animal a){
        if (a.getX() < 0 || a.getY() < 0 || a.getY() >= river[a.getX()].length||a.getX()>=river.length)
            return false;
        river[a.getX()][a.getY()] = a;
        return true;
    }
    public Animal getAnimalAt(int x, int y){
        if (x < 0 || y < 0 ||y >= river[x].length||x>=river.length)
            throw new ArrayIndexOutOfBoundsException("Position outside River area");
        return river[x][y];
}
    public Animal getNeighborUp(Animal a){
        if (a.getX() < 0 || a.getY() < 0 || a.getY()+1 >= river[a.getX()].length||a.getX()>=river.length)
            return new Wall();
        else
            return river[a.getX()][a.getY()+1];
    }
    public Animal getNeighborDown(Animal a){
        if (a.getX() < 0 || a.getY()-1 < 0 || a.getY() >= river[a.getX()].length||a.getX()>=river.length)
            return new Wall();
        else
            return river[a.getX()][a.getY()-1];
    }
    public Animal getNeighborRight(Animal a){
        if (a.getX() < 0 || a.getY() < 0 || a.getY() >= river[a.getX()].length||a.getX()+1>=river.length)
            return new Wall();
        else
            return river[a.getX()+1][a.getY()];
    }
    public Animal getNeighborLeft(Animal a){
        if (a.getX()-1 < 0 || a.getY() < 0 || a.getY() >= river[a.getX()].length||a.getX()>=river.length)
            return new Wall();
        else
            return river[a.getX()-1][a.getY()];
    }
    public String toString(){
        String out = "";
        for (int i =0; i<river.length;i++){
            for(int in =0; in<river[i].length;in++){
                if (river[i][in]==null)
                    out+=" - ";
                else
                    out+=" "+river[i][in].getSymbol()+" ";
            }
            out+="\n";
        }
        return out;
    }
}
