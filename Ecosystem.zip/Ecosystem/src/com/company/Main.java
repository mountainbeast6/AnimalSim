package com.company;

public class Main {

    public static void main(String[] args) {
	    River river = new River();
	    river.addAnimal(new Animal(9, 9));
        river.addAnimal(new Animal(2, 0));
	    System.out.print(river.toString());
    }
}
