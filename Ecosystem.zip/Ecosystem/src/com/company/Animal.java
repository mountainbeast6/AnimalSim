package com.company;

public class Animal {
    private int x;
    private int y;
    private String Symbol;
    public Animal (int x, int y){
        Symbol = "a";

        this.x = x;

        this.y = y;
    }
    public Animal (String a, int x, int y){
        Symbol = a;

        this.x = x;

        this.y = y;
    }
    public void setSymbol(String symbol) {
        Symbol = symbol;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getSymbol() {
        return Symbol;
    }



    public void Move(Animal up, Animal down, Animal left, Animal right){

    }
}
