package com.company;

public class Wall extends Animal {

    public Wall() {
        super("a",0, 0);
    }
}
